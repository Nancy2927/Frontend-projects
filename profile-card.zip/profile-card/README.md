# Profile Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nancy2927/pen/GRzgXNq](https://codepen.io/Nancy2927/pen/GRzgXNq).

I have used HTML and CSS to create the UI for profile card.